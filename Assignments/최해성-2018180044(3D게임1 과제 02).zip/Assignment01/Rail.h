#pragma once
#include "stdafx.h"
class CRail
{
private:
public:
	CRail() {};
	~CRail() {};
	
};

